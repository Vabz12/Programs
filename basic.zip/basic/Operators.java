package basic;

public class Operators {

	public static void main(String[] args) {
		int i = 10;
		int j = 10;
		
//		System.out.println(i++);
//		System.out.println(i+1);
//		System.out.println(i += j);
//		System.out.println(++i);
		System.out.println(--i);
		
		System.out.println(j++);
		System.out.println(++j);
		
	}
}
