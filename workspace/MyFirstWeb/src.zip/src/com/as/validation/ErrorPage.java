package com.as.validation;

public interface ErrorPage {
	
	public static final String USER_FIRST_NAME = "Please enter First Name . <br>";
	public static final String USER_MIDDLE_NAME = "Please enter Middle Name . <br>";
	public static final String USER_LAST_NAME = "Please enter Last Name . <br>";
	public static final String USER_GENDER = "Please enter Gender . <br>";
	public static final String USER_ADDRESS = "Please enter Address . <br>";
	public static final String USER_CITY = "Please enter your City . <br>";
	public static final String USER_STATE = "Please enter your State . <br>";
	public static final String USER_COUNTRY = "Please enter your Country . <br>";
	public static final String USER_PHONE = "Please enter your Phone . <br>";
	public static final String USER_BANK_NAME = "Please enter your Bank Name . <br>";
	public static final String USER_ACCOUNT_NO = "Please enter your Account Number . <br>";
	public static final String USER_SSN = "Please enter your SSN . <br>";
}
